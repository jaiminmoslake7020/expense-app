import React from 'react';
import { useQuery } from '@tanstack/react-query';
import Button from '../components/ui/button.jsx';

/**
 * Fetch posts from a public JSON API. We limit the posts to a handful to avoid large payloads.
 */
const fetchPosts = async () => {
  const response = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=5');
  if (!response.ok) {
    throw new Error('Failed to fetch posts');
  }
  return response.json();
};

export default function Home() {
  const { data: posts, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['posts'],
    queryFn: fetchPosts
  });

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Recent Posts</h2>
      <Button onClick={() => refetch()} className="mb-4">Refresh</Button>
      {isLoading && <p>Loading...</p>}
      {isError && <p className="text-red-500">{error.message}</p>}
      <ul className="space-y-2">
        {posts?.map(post => (
          <li key={post.id} className="rounded-lg border p-4 shadow-sm bg-white">
            <h3 className="font-medium text-lg">{post.title}</h3>
            <p className="text-sm text-muted-foreground">{post.body}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}