import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import App from './App.jsx';
import './index.css';

// Create a client for React Query.
const queryClient = new QueryClient();

// Hydrate the root element with our React application.
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* React Query provider supplies caching and data-fetching capabilities to our app */}
    <QueryClientProvider client={queryClient}>
      {/* BrowserRouter from React Router sets up client‑side routing */}
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);