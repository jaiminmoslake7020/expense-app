import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    // Enables React fast refresh and JSX transformation
    react(),
    // Integrates Tailwind CSS v4.1+ using the official Vite plugin
    tailwindcss()
  ],
  resolve: {
    // Provide a convenient alias for the src directory
    alias: {
      '@': new URL('./src', import.meta.url).pathname
    }
  },
  server: {
    port: 5173
  }
});